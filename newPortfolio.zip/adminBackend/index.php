<?php include 'layout/header.php'; ?>


<!-- Sidenav Menu Start -->
<?php include 'layout/sidebar.php'; ?>
<!-- Sidenav Menu End -->


<!-- Topbar Start -->
<?php include 'layout/topbar.php'; ?>
<!-- Topbar End -->

<!-- ================================== -->
<!-- Start Page Content here -->
    <?php include 'dashboardContent.php';?>

<!-- Start footer -->
<?php include 'layout/footer.php'; ?>