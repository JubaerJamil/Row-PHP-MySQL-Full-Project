<div
      class="w-100 bgn1-color p-3 position-fixed z-3 top-0 d-lg-none d-flex align-items-center justify-content-between br-bottom-n5 box-shadow1">
      <a href="index.php" class="side-icon bgn2-color brn4">
      <img src="assets/images/faviconjjjjj_.png" width="17px" height="22px" alt="">
      </a>

      <div class="d-flex gap-3 align-items-center">
        <a href="checkout.php" class="position-relative">
          <div class="side-icon bg1-color">
            <i class="ph ph-shopping-cart n11-color"></i>
          </div>
          <div class="cart-counter-header">
            <span class="n1-color">00</span>
          </div>
        </a>
        <button class="side-icon bg1-color mood_toggle">
          <i class="mood_icon ph-fill ph-moon fs-six n11-color"></i>
        </button>
      </div>
    </div>