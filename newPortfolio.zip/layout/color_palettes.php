<div class="color-switcher">
      <button class="switcher-btn">
        <i class="ph ph-gear-six"></i>
      </button>
      <div class="pallates box-shadow2 brn4">
        <div class="d-flex gap-2">
          <button class="color-btn bg-color1" data-color="120, 171, 168"></button>
          <button class="color-btn bg-color2" data-color="255, 145, 251"></button>
          <button class="color-btn bg-color3" data-color="253, 187, 46"></button>
        </div>
        <div class="d-flex gap-2 mt-2">
          <button class="color-btn bg-color4" data-color=" 82, 113, 255"></button>
          <button class="color-btn bg-color5" data-color=" 0, 255, 255"></button>
          <button class="color-btn bg-color6" data-color="84, 182, 137"></button>
        </div>
      </div>
    </div>