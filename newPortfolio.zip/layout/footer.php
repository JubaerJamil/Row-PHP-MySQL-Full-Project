<section
        class="container d-flex flex-wrap gap-3 gap-md-6 justify-content-center justify-content-sm-between align-items-center pb-4 pb-md-8 text-center mb-16 mb-lg-0">

        <span class="fs-eight fw-medium n5-color order-sm-1">Copyright © <?php echo date("Y");?>
          <a href="https://jubaerjamil.com/" target="_blank" class="fs-eight fw-medium n5-color" style="color: gray;">Jubaer Jamil</a>. All Rights Reserved.</span>
      </section>
      <!-- footer section end -->
    </div>
  </div>

  <!-- script js  -->
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="assets/js/plugins/plugins.js"></script>
  <script src="assets/js/main.js"></script>
  <script src="assets/js/type-word.js"></script>
  <!-- swiper js  -->
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <!-- email js  -->
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
  <!-- aos -->
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

  <!--what's app script-->
<script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
<div class="elfsight-app-a84d2e4a-8eca-4134-bc22-f97e5576a852" data-elfsight-app-lazy></div>
</body>

</html>